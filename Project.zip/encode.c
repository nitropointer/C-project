/* 
Name					: Harsh Shah
Date					: 12/03/2022
Project Name			: LSB image steganography
File Name				: Encode.c file
Input					: For encoding: ./a.out -e beautiful.bmp secret.txt stego.bmp
Output					: Selected encoding
						  Read and validate encode arguments is a success
						  Started encoding.....................
						  Open files is a success
						  width = depends on image.bmp
						  height = depends on image.bmp
					      Check capacity is a success
						  Copied bmp header successfully
						  Encoded magic string successfully
						  Encoded the extn size
						  Encoded secret file extn
						  Encode secret file size
						  Encoded secret file data
						  Copied Remaining data
						  .......Completed Encoding......

*/

#include <stdio.h>						//header file 
#include <string.h>						//header files for string
#include "encode.h"						//header fil for encode
#include "types.h"						//header file for enum 
#include "common.h"						//header files for magic string

//start
/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}

//This function is to read and validate command line arguments passed by user 
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
	if(strcmp(strstr(argv[2], "."),  ".bmp") == 0)				//extracting .bmp and comparing it with argv[2]
		encInfo -> src_image_fname = argv[2];					//if strcmp is success then storing in struct variable
	else
		return e_failure;										//if it fails then returns e_failure
	if(strcmp(strstr(argv[3], "."), ".txt") == 0)				//extracting .txt and comparing it with argv[3]
		encInfo -> secret_fname = argv[3];						//if strcmp is success then storing in struct variable
	else
		return e_failure;										//if it fails then returns e_failure

	if(argv[4] != NULL)											//if stego.bmp is passed then storing it in struct variable
		encInfo -> stego_image_fname = argv[4];
	else
		encInfo -> stego_image_fname = "stego.bmp";				//if stego.bmp is not passed then creating new stego.bmp file

	return e_success;											//No failure and returns e_success
}

//this function is to check image and secret file capacity 
Status check_capacity (EncodeInfo *encInfo)
{
	//storing image size in struct variable image capacity using get image sizefor bmp function
	encInfo -> image_capacity = get_image_size_for_bmp(encInfo -> fptr_src_image);

	//storing size of secret file in struct variable using get file size
	encInfo -> size_secret_file = get_file_size(encInfo -> fptr_secret);

	//comparing image size with size of secret file and its extension 
	if(encInfo -> image_capacity > ((2 + 4 + 4 + 4 + encInfo -> size_secret_file)*8))
		return e_success;					//if size is less than returns e_success
	else
		return e_failure;					//if size is more than returns e_failure

}

//This function is to get secret file size
uint get_file_size(FILE *fptr)
{
	fseek(fptr, 0, SEEK_END);					//moving at 0th position to end position of file uisng fseek and file pointer
	return ftell(fptr);							//returning size of file uisng ftell
}

//This is the function to copy header of bmp file from source to destination using file pointers
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
	fseek(fptr_src_image, 0, SEEK_SET);					//setting at oth position of source image
	char str[54];										//taking char array of 54 bytes
	fread(str ,54,1, fptr_src_image);					//reading all 54 bytes of source image using fread and storing in array
	fwrite(str ,54,1, fptr_dest_image);					//writing all 54 bytes into destination image from array using fwrite
	return e_success;									//if writing is successful then returns e_success
}

//this is the function to encode magic string
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
	//storing magic string in dsetination image using encode data to image
	encode_data_to_image(magic_string,strlen(magic_string), encInfo-> fptr_src_image, encInfo->fptr_stego_image, encInfo);
	return e_success;								//returns e_success if no failure is there
}

//this is the funciton to encode secret file extension(.txt)
Status encode_secret_file_extn(char *file_extn, EncodeInfo *encInfo)
{
	//storing extension in destination image using encode data to image 
	encode_data_to_image(file_extn,strlen(file_extn), encInfo-> fptr_src_image, encInfo->fptr_stego_image, encInfo);
	return e_success;								//return e_success if no failure is there
}

//this funciton is encode secret file data into destination image
Status encode_secret_file_data(EncodeInfo *encInfo)
{
	char str[encInfo -> size_secret_file];			//taking array to size of file
	fseek(encInfo -> fptr_secret, 0, SEEK_SET);				//setting position at 0 using fseek
	fread(str, encInfo -> size_secret_file, 1, encInfo -> fptr_secret);			//reading secret file and storing in array
	
	//passing array address to encode into image using encode data to image function
	encode_data_to_image(str , strlen(str), encInfo-> fptr_src_image, encInfo->fptr_stego_image, encInfo);
	return e_success;
}

//this function is to encode magic string and secret file extension
Status encode_data_to_image(const char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image, EncodeInfo *encInfo)
{
	int i;
	for(i=0;i<size;i++)	
	{
		fread (encInfo -> image_data, 8,1,fptr_src_image);				//reading 8 bytes using loop and stroing in image data 
		encode_byte_to_lsb(data[i], encInfo->image_data);				//encode this 8 bytes into lsb using this function
		fwrite(encInfo -> image_data, 8, 1, fptr_stego_image);			//writing this lsb bytes into destination image
	}
}

//This function is to encode bytes into lsb of destination image
Status encode_byte_to_lsb(char data, char *image_buffer)
{
	int i;
	for(i=0;i<8;i++)					
	{
		//using loop storing data into bytes of lsb
		image_buffer[i] = (image_buffer[i] & 0xFE) | ((data >> (7-i)) &1);
	}
}

//This is the funciton to encode extension size into destination image
Status encode_extn_size(int size, EncodeInfo *encInfo)
{
	char str[32];													//taking array of 32 bytes
	fread(str, 32,1,encInfo -> fptr_src_image);						//reading 32 bytes of source image and storing into array
	encode_size_to_lsb(size,str);									//send this array address to encode into lsb bytes
	fwrite (str, 32,1, encInfo->fptr_stego_image);					//writing this 32 bytes into lsb destination image using fwrite
	return e_success;												//if no failure then returns e_success
}

//This function is to encode total size of secret file 
Status encode_secret_file_size(int file_size, EncodeInfo *encInfo)
{
	char str[32];												//taking array of 32 bytes
	fread(str, 32,1,encInfo -> fptr_src_image);					//reading 32 bytes of source image and storing into array
	encode_size_to_lsb(file_size,str);							//sending address for encoding into lsb 
	fwrite (str, 32,1, encInfo->fptr_stego_image);				//writing this 32 bytes into lsb of destination image 
	return e_success;											//if no failure then returns e_success
}

//This function is to encode whole size into destination image 
Status encode_size_to_lsb(int size, char *image_buffer)
{
	int i;
	for(i=0; i<32; i++)
	{
		//using loop storing data into lsb 
		image_buffer[i] = (image_buffer[i] & 0xFE) | ((size>>(31-i) & 1));
	}
}

//This function is to copy remaining data of image into destination image 
Status copy_remaining_img_data(FILE *fptr_src_image, FILE *fptr_dest_image)
{
	char ch;
	while(fread(&ch ,1, 1, fptr_src_image)>0)   //using loop and fread writing remaining data into destination image 
	{
		fwrite(&ch, 1, 1, fptr_dest_image);
	}
	return e_success;							//if no failure then returns success
}

//This function does the encoding
Status do_encoding(EncodeInfo *encInfo)
{
	if(open_files(encInfo) == e_success)			//functon of open files
	{
		printf("Open files is a success\n");
		if(check_capacity(encInfo) == e_success)		//function of check capacity
		{
			printf("Check capacity is a success\n");
			if(copy_bmp_header(encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)	//function of bmp header
			{
				printf("Copied bmp header successfully\n");
				if(encode_magic_string(MAGIC_STRING, encInfo) == e_success)		//function of encoding magic string
				{
					printf("Encoded magic string successfully\n");
					strcpy(encInfo -> extn_secret_file , strstr(encInfo -> secret_fname, "."));
					if(encode_extn_size(strlen(encInfo -> extn_secret_file), encInfo) == e_success)		//function of extension size
					{
						printf("Encoded the extn size\n");
						if(encode_secret_file_extn(encInfo->extn_secret_file, encInfo) == e_success)	//function of secret file extension
						{
							printf("Encoded secret file extn\n");
							if(encode_secret_file_size(encInfo -> size_secret_file, encInfo) == e_success)	//function of secret file size
							{
								printf("Encode secret file size\n");
								if(encode_secret_file_data(encInfo) == e_success)		//function of encoding secret file data
								{
									printf("Encoded secret file data\n");
									//function of copying remaining data
									if(copy_remaining_img_data(encInfo -> fptr_src_image, encInfo -> fptr_stego_image) == e_success)
									{
										printf("Copied Remaining data\n");
									}
									else
									{
										printf("Failed to copy remaining data\n");
										return e_failure;
									}
								}
								else
								{
									printf("Failed to Encoded secret file data\n");
								}
							}
							else
							{
								printf("Failed to encode secret file size\n");
								return e_failure;
							}
						}
						else
						{
							printf("Failes to encode secret file extn\n");
							return e_failure;
						}
					}
					else
					{
						printf("Encode extn done failed\n");
						return e_failure;
					}
				}
				else
				{
					printf("Failes to Encod magic string \n");
					return e_failure;
				}
			}
			else
			{
				printf("Failed to copy bmp header\n");
				return e_failure;
			}
		}
		else
		{
			printf("Check capacity is a failure\n");
			return e_failure;
		}

	}
	else
	{
		printf("Open files is a failure\n");
		return e_failure;
	}
	return e_success;
}
//stop
