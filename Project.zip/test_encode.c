/*
Name                    : Harsh Shah
Date                    : 12/03/2022
Project Name            : LSB image steganography
File	                : test_encode.c file
*/

#include <stdio.h>							//header files
#include <string.h>							//header files for string
#include "encode.h"							//header files for encode
#include "decode.h"							//header files for decode
#include "types.h"							//header files for types

//start
int main(int argc, char **argv )					//main function and passing command line arguments
{
	//for encoding operation
	if(check_operation_type(argv) == e_encode)
	{
		printf("Selected encoding\n");
		EncodeInfo encInfo;
		if(read_and_validate_encode_args(argv, &encInfo) == e_success)
		{
			printf("Read and validate encode arguments is a success\n");
			printf("Started encoding.....................\n");
			if(do_encoding(&encInfo) == e_success)
			{
				printf(".......Completed Encoding......\n");
			}
			else
			{
				printf(".......Encoding failed......\n");
			}

		}
		else
		{
			printf("Read and validate encode arguments is a failure\n");
			return -1;
		}
	}
	//for decoding operation
	else if(check_operation_type(argv) == e_decode)
	{
		printf("Selected decoding\n");
		DecodeInfo decInfo;
		if(read_and_validate_decode_args(argv, &decInfo) == e_success)
		{
			printf("Read and validate decode arguments is successful\n");
			printf("Started Decoding.....................\n");
			if(do_decoding(&decInfo) == e_success)
			{
				printf(".......Completed Decoding......\n");
			}
			else
			{
				printf(".......Decoding failed......\n");
			}
		}
		else
		{
			printf("Read and validate decode arguments is failure\n");
			return -1;
		}
	}
	//if no decoding operation or no encoding operation is selected then printing error
	else
	{
		printf("Invalid option\nFor encoding: ./a.out -e beautiful.bmp secret.txt stego.bmp\nFor decoding: ./a.out -d stego.bmp decode.txt\n");
	}
    return 0;
}

//this is the function to check command line arguments
OperationType check_operation_type(char *argv[])
{
		if(argv[1] == NULL)						//if argv[1] is NULL then returns e_unspported
				return e_unsupported;
		if(strcmp(argv[1], "-e") == 0)			//if argv[1] is -e then returns e_encode
			return e_encode;
		else if(strcmp(argv[1] , "-d") == 0)		//if argv[2] is -d then returns e_decode
			return e_decode;
		else
			return e_unsupported;				//returns e_unspported is no option is selected
}
//stop
