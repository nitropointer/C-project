#ifndef DECODE_H
#define DECODE_H

#include "types.h" // Contains user defined types

/* 
 * Structure to decode data from stego image
 * all information for decode file and stego file is provided in struct 
 */
typedef struct _DecodeInfo
{
    /*secret file info*/
    char *src_image_fname;
    FILE *fptr_src_image;
    uint extn_size;
    uint secret_file_extn_size;
    uint file_size;
    char *secret_file_extn;

    /*Decode file info*/
    char *decode_fname;
    FILE *fptr_decode;
    
    /* Stego Image Info */
    char *stego_image_fname;
    FILE *fptr_stego_image;
   
   /*magic string id*/	
    char *magic_string_id;

} DecodeInfo;


/* Decoding function prototype */

/* Read and validate decode args from argv */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/* Perform the Decoding */
Status do_decoding(DecodeInfo *decInfo);

/* Get File pointers for stego.bmp and decode.txt */
Status open_file(DecodeInfo *DecInfo);

/* Decode Magic String */
Status Decode_magic_string(DecodeInfo *decInfo);

/* Decode a magic string bytes from LSB of image data array */
Status Decode_byte_from_lsb(char *data, char *magic);

/* Decode extn size*/
Status Decode_extn_size(DecodeInfo *decInfo);

/*Decode extn from lsb*/
Status Decode_secret_file_extn(DecodeInfo *decInfo);

/* Decoding extn bytes from lsb of image data array */
Status Decode_extn_bytes_from_lsb(char *file_extn, DecodeInfo *decInfo);

/* Decode secret file size */
Status Decode_secret_file_size(DecodeInfo *decInfo);

/* Creating secret file */
Status Creating_decode_file(DecodeInfo *decInfo);

/* Decoding data from image*/
Status Decode_data_from_image(DecodeInfo *decInfo);

#endif
