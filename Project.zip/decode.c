/*
Name                    : Harsh Shah
Date                    : 12/03/2022
Project Name            : LSB image steganography
File Name               : Decode.c file
Input                   : For decoding: ./a.out -d stego.bmp
Output					: Selected decoding
						  Read and validate decode arguments is successful
						  Started Decoding.....................
						  Open files is success
						  Magic string is #*
						  Magic string is matched, decoding can be continued
						  size of secret file extension is 4 bytes
						  Decoded extn size successfully
						  Extension of secret file is .txt
						  Decoded extension successfully
						  size of secret file is <depends on secret file> bytes
					      Size of secret file found successfully
						  Decode file created successfully
						  Fetched all data from image which was encoded
						  .......Completed Decoding......

*/

#include<stdio.h>						//header files
#include<string.h>						//header for string
#include"decode.h"						//header for decode.h
#include"common.h"						//header for common.h
#include"types.h"						//header for types.h
#include<stdlib.h>						//header for stdlib.h

//start
//This is the function to open file and store it in struct varibale
Status open_file(DecodeInfo *decInfo)
{	
	//opening decode.txt in write mode and storing it in struct variable of fptr decode
	decInfo->fptr_decode = fopen(decInfo -> decode_fname, "w");
     if (decInfo -> fptr_decode== NULL)
     {
		 //if failed to open file then printing error
         perror("fopen");
         fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo -> decode_fname );
         return e_failure;				//returns e_failure if failed to open files
	 }
	
	//opening stego.bmp in read mode and storing it in struct variable of fptr_stego_image
	decInfo -> fptr_stego_image = fopen(decInfo -> stego_image_fname, "r");
	if (decInfo -> stego_image_fname == NULL)
    {
		//if failed to open files then printing error
    	perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo-> stego_image_fname);
        return e_failure;				//returns e_failure if failed to open file
    }
	return e_success;					//returns e_success if no failure occurs
}

//This function is to decode magic string from stego.bmp
Status Decode_magic_string(DecodeInfo *decInfo)
{
	int i,len;												//initializing i and len as int
	char str[8];											//initializing string array of 8 bytes
	decInfo -> magic_string_id = MAGIC_STRING;				//storing magic string in struct variable
	fseek(decInfo -> fptr_stego_image , 54 , SEEK_SET);		//setting position in stego.bmp at 54th one using fseek
	len = strlen(decInfo -> magic_string_id);				//defining length of magic string and storing it in len variable
	char compare[len];										//defining compare as length of magic string
	for(i=0;i<len;i++)
	{
		fread(str, 8,1, decInfo -> fptr_stego_image);		//using loop and fread read 8 bytes(2times) and storing it in str variable 
		Decode_byte_from_lsb(str, &compare[i]);				//passing str address and compare to decode_bytes_from_lsb to find all bytes of magic string 
	}
	compare[i] = '\0';		
	printf("Magic string is %s\n", compare);				//printing magic string
	for(i=0;i<len;i++)
	{
		if( decInfo -> magic_string_id[i] && compare[i])		//using loop to compare data retrieved from stego.bmp and magic string 
			if(decInfo -> magic_string_id[i] != compare[i])	
			return e_failure;									//if comparison fails then returns e_failure
	}
	return e_success;									//if no failures occurs then returns e_success
}

//This function is to decode bytes of magic string from lsb
Status Decode_byte_from_lsb(char *data, char *magic)
{
	int i,j=7;										//initializing i,j and ch 
	char ch = 0x00;
	for(i=0;i<8;i++)
	{
		ch = ch | ((data[i] & 1 ) << j);					//using loop to find all the bytes of magic string
		j--;
	}
	*magic = ch;										//storing in magic pointer
	return e_success;									//return _success if no failure occurs
}

//This function is to decode extension size of secret file
Status Decode_extn_size(DecodeInfo *decInfo)
{
	int i,j=31;										//initilizing j and string array of 32 bytes to store all bytes of extn size
	char str[32];
	uint size=0;									//initializing size as 0
	fread(str, 32, 1, decInfo -> fptr_stego_image);			//reading stego.bmp image 32 bytes and storing it in str
	for(i=0; i<32; i++)
	{
		size = size | ((str[i] & 1) << j);			//decoding size of extn and stroing it in size using left shift operator
		j--;
	}
	decInfo -> secret_file_extn_size = size;
	//prinitng size of secret file extension
	printf("size of secret file extension is %u bytes\n", decInfo -> secret_file_extn_size);
	return e_success;							//returns e_success if no failure occurs
}

//This function is to decode secret file extension
Status Decode_secret_file_extn(DecodeInfo *decInfo)
{
	int i;
	//allocating memory to extension size of secret file and storing it in struct variable
	decInfo -> secret_file_extn = malloc(decInfo -> secret_file_extn_size);	
	for(i=0; i<decInfo -> secret_file_extn_size;i++)
	{
		//function to decode all bytes of extension from stego.bmp
		Decode_extn_bytes_from_lsb(&decInfo ->secret_file_extn[i] , decInfo);
	}
	decInfo-> secret_file_extn[i] = '\0';
	//printing extension of secret file
	printf("Extension of secret file is %s\n", decInfo -> secret_file_extn);
	return e_success;							//returns e_success if no failure occurs
}

//This function is to decode extension bytes from lsb
Status Decode_extn_bytes_from_lsb(char *ptr, DecodeInfo  *decInfo)
{
	int i,j=7;
	char ch = 0x00, str[8];						//initializing ch, str array of 8 bytes
	fread(str, 8, 1, decInfo -> fptr_stego_image);			//reading 8 bytes of stego.bmp 4 times and storing it in str
	for(i=0;i<8;i++)
	{
		ch = ch | ((str[i] & 1) << j);			//storing all bytes in ch using loop and left shift operator
		j--;
	}	
	*ptr = ch;									//storing all bytes in ptr pointer
	return e_success;						    //returns e_success if no failure occurs
}

//This is the function to decode secret file size from stego.bmp
Status Decode_secret_file_size(DecodeInfo *decInfo)
{
	int i;
	int j = 31;
	char str[32];								//initializing j, str array of 32 bytes
	uint size=0;								//initializing size as 0
	fread(str,32,1, decInfo -> fptr_stego_image);			//reading 32 bytes from stego.bmp and storing it in str
	for(i=0;i<32;i++)
	{
		size = size | ((str[i] & 1) << j);		//storing it in size variable using left shift operator
		j--;
	}
	decInfo -> file_size = size;				//storing size in struct variable
	//printing size of secret file
	printf("size of secret file is %u bytes\n", decInfo -> file_size);
	return e_success;							//if no failure occurs then returns e_success			
}

//This is the function to create decode file
Status Creating_decode_file(DecodeInfo *decInfo)
{	
	//opens decode files in write mode using fopen and storing it in struct variable
	decInfo -> fptr_decode = fopen("decode.txt", "w");
	return e_success;							//returns e_success if no failure occurs
}

//This is the function to decode all data according to size of file and writing it in decode file
Status Decode_data_from_image(DecodeInfo *decInfo)
{
	char ch;
	int i=0;
	while(i<decInfo->file_size)
	{
		//this is the function to decode all the data of secret file from stego.bmp lsb
		Decode_extn_bytes_from_lsb(&ch,decInfo);			
		fwrite(&ch, 1,1,decInfo -> fptr_decode);			//writing all the bytes into decode file using loop
		i++;
	}
	return e_success;							//if no failure occurs then returns e_success
}

//this is the function to read and validate arguments passed in command line
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
	//using string compare comparing argv[2] arguments with .bmp 
	if(strcmp(strstr(argv[2], "."), ".bmp") == 0)
		decInfo	-> stego_image_fname = argv[2];				//storing argv[2] in struct variable
	else
		return e_failure;									//if comparing fails then returns e_failure
	if(argv[3] != NULL)										//if argv[3] is passed then storing it struct variable
		decInfo -> decode_fname = argv[3];					
	else
		decInfo -> decode_fname = "decode.txt";				//if argv[3] not passed then creating decode file

	return e_success;										//returns e_success if no failure occurs
}

//This is the function to do decoding
Status do_decoding(DecodeInfo *decInfo)
{
	if(open_file(decInfo) == e_success)					//function of opening files
	{
		printf("Open files is success\n");		
		if(Decode_magic_string(decInfo) == e_success)		//function of decoding magic string
		{
			printf("Magic string is matched, decoding can be continued\n");
			if(Decode_extn_size(decInfo) == e_success)				//function of decoding extn size
			{
				printf("Decoded extn size successfully\n");
				if(Decode_secret_file_extn(decInfo) == e_success)			//function of decoding secret file extn
				{
					printf("Decoded extension successfully\n");
					if(Decode_secret_file_size (decInfo) == e_success)				//function of decoding secret file size
					{
						printf("Size of secret file found successfully\n");				
						if(Creating_decode_file(decInfo) == e_success)						//function of creating decode file
						{
							printf("Decode file created successfully\n");
							if(Decode_data_from_image(decInfo) == e_success)					//function of decoding data from image 
							{
								printf("Fetched all data from image which was encoded\n");
							}
							else
							{
								printf("Failed to decode all the data from image\n");
								return e_failure;
							}
						}
						else
						{
							printf("Failed to create decode file\n");
							return e_failure;
						}
					}
					else
					{
						printf("Failed to find decode file size\n");
						return e_failure;
					}
				}
				else
				{
					printf("Failed to decode extension\n");
					return e_failure;
				}
			}
			else
			{
				printf("Failed to decode extn size\n");
				return e_failure;
			}
		}
		else
		{
			printf("Magic string are different, decoding can't be done further\n");
			return e_failure;
			exit(0);
		}
	}
	else
	{
		printf("Failed to open files\n");
		return e_failure;
	}
	return e_success;
}
//stop
